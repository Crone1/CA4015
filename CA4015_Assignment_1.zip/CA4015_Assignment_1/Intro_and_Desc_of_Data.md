## INTRODUCTION AND DESCRIPTION OF DATASET

Each of the datasets which we are analysing comprise 63 older people (between 65-88 years) and 90 younger people (between 18-34 years) who completed a computerised version of the Iowa Gambling Task [IGT]. This is a widely used cognitive task for assessing the decision-making of a human being [Insert reference to Lili's paper]. Each dataset contains the parameters, for each subject, of a reinforcement learning model which was applied to simulate the subject's actions or decision-making process while completing the IGT. We are analysing three different models which were utilised in Lili's paper, namely the:

- Outcome Representation Learning Model [ORL][1]
- Prospect Valence Learning Model with Delta [PVL-Delta][2]
- Values-Plus-Perserverance Model [VPP] [3]

The parameters of these models can be interpreted as several different underlying physcological processes such as learning from experience and sensitivity to rewards and punishments etc. [Reference to Lili's paper again?] which contribute to the human decision-making process.  In our analysis, we will use a variety of clustering techniques in order to segment the subject group into distinct clusters. Intuitively, these clusters will represent groups of subjects who make decisions in a similar manner, according to the cognitive processes captured by the parameters of the various models.

This is the structure that the jupyter notebook in the next section follows

	1. Setup

	2. Reading in the data

	3. Scaling the data

	4. Consider clustering algorithms and cluster count

	5. Cluster data using 2 clusters

	6. Analyse these 2 clusters

	7. Re-consider clustering algorithms and cluster count

	8. Re-cluster data using 6 clusters

	9. Principal Component Analysis

	10. Plot the 6 clusters using the Principal Component Analysis Axes

	11. Analyse these 6 clusters
